import json
import requests

def handler(event, context):
    # Example consumer
    pass
